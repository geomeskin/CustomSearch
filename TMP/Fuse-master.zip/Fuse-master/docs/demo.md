# Live Demo

Play around with a live demo of Fuse.js. Have a look at the [options](api/options.html) to understand what they mean.

<!--
::: slot middle
Modify the `options` and/or `pattern`:
::: -->

<ClientOnly>
  <Demo />
</ClientOnly>
