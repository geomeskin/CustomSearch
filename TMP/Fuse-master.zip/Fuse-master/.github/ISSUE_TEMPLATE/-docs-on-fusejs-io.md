---
name: "\U0001F4DA Docs on fusejs.io"
about: Report an issue in Fuse.js documentation or fusejs.io
title: ''
labels: docs
assignees: ''

---

<!--
Love Fuse.js? Please consider supporting:

👉https://github.com/sponsors/krisk
👉https://www.patreon.com/krisk
👉https://www.paypal.com/paypalme2/kirorisk
-->
