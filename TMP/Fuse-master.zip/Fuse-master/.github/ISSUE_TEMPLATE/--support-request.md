---
name: "❓ Support request"
about: Questions and requests for support.
title: ''
labels: question
assignees: ''

---

<!--
Love Fuse.js? Please consider supporting:

👉https://github.com/sponsors/krisk
👉https://www.patreon.com/krisk
👉https://www.paypal.com/paypalme2/kirorisk
-->
