// Machine word size
export const MAX_BITS = 32
