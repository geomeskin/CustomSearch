import BitapSearch from './bitap'
import ExtendedSearch from './extended'

export { BitapSearch, ExtendedSearch }
