module.exports = {
  testEnvironment: 'node',
  testMatch: ['<rootDir>/test/*.test.(ts|js)']
}
