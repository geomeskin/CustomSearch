module.exports = require('./lib/fuzzyset.js');
